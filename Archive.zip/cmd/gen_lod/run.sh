#!/usr/bin/env bash
#
# Runs all gen_lod.py blender jobs in parallel, waits for all to finish,
# and reports per-job status. Output from all jobs streams directly to
# the console (interleaved) — nothing is captured to log files.
#
# Usage: ./run_lods_parallel.sh

set -u

# Each entry: "name|src|dst"
JOBS=(
  "vanilla|/home/ern/tes3/mdataextract/meshes/x|/home/ern/workspace/ErnLODMeshes/Vanilla Data 01/meshes/x"
  "mop|/home/ern/tes3/mods/Performance/MorrowindOptimizationPatch/00 Core/meshes/x|/home/ern/workspace/ErnLODMeshes/MOP Data 03/meshes/x"
  "tr_x|/home/ern/tes3/mods/ModdingResources/TamrielData/00 Data Files/meshes/tr/x|/home/ern/workspace/ErnLODMeshes/TR Data 02/meshes/tr/x"
  "tr_sum|/home/ern/tes3/mods/ModdingResources/TamrielData/00 Data Files/meshes/sum/x|/home/ern/workspace/ErnLODMeshes/TR Data 02/meshes/sum/x"
  "tr_sky|/home/ern/tes3/mods/ModdingResources/TamrielData/00 Data Files/meshes/sky/x|/home/ern/workspace/ErnLODMeshes/TR Data 02/meshes/sky/x"
  "tr_pi|/home/ern/tes3/mods/ModdingResources/TamrielData/00 Data Files/meshes/pi/x|/home/ern/workspace/ErnLODMeshes/TR Data 02/meshes/pi/x"
  "tr_pc|/home/ern/tes3/mods/ModdingResources/TamrielData/00 Data Files/meshes/pc/x|/home/ern/workspace/ErnLODMeshes/TR Data 02/meshes/pc/x"
  "tr_hr|/home/ern/tes3/mods/ModdingResources/TamrielData/00 Data Files/meshes/hr/x|/home/ern/workspace/ErnLODMeshes/TR Data 02/meshes/hr/x"
  "tr_hf|/home/ern/tes3/mods/ModdingResources/TamrielData/00 Data Files/meshes/hf/x|/home/ern/workspace/ErnLODMeshes/TR Data 02/meshes/hf/x"
  "atlas|/home/ern/tes3/mods/Performance/Project Atlas/00 Core/meshes/x|/home/ern/workspace/ErnLODMeshes/Project Atlas Data 04/meshes/x"
  "gitd|/home/ern/tes3/mods/Lighting/GlowintheDahrk/00 Core/Meshes/x|/home/ern/workspace/ErnLODMeshes/GitD Data 05/meshes/x"
)

names=()
pids=()

echo "Launching ${#JOBS[@]} jobs in parallel..."
echo

for job in "${JOBS[@]}"; do
  IFS='|' read -r name src dst <<< "$job"

  blender-5.1 --background \
    --python cmd/gen_lod/gen_lod.py \
    -- \
    "$src" \
    "$dst" &

  pid=$!
  names+=("$name")
  pids+=("$pid")

  echo "  [started] $name (pid $pid)"
done

echo
echo "Waiting for all jobs to complete..."
echo

failures=0
for i in "${!pids[@]}"; do
  pid="${pids[$i]}"
  name="${names[$i]}"

  if wait "$pid"; then
    echo "  [ OK ]   $name (pid $pid)"
  else
    code=$?
    echo "  [FAIL]   $name (pid $pid, exit $code)"
    failures=$((failures + 1))
  fi
done

echo
if [ "$failures" -eq 0 ]; then
  echo "All ${#JOBS[@]} jobs completed successfully."
else
  echo "$failures of ${#JOBS[@]} job(s) failed."
fi

exit "$failures"
